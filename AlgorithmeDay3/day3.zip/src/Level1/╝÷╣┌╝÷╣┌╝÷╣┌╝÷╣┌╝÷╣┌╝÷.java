package Level1;

public class 수박수박수박수박수박수 {

	public static void main(String[] args) {
		int n = 17; // "수박수" n : 자연수(10000이하)

		Solution6 sol = new Solution6();
		String result = sol.solution(n);
		System.out.println(result);
	}

}

class Solution6 {
	public String solution(int n) {
		String answer = "";

		for (int i = 0; i < n; i++) {
			if (i % 2 == 0) {
				answer += "수";
			} else {
				answer += "박";
			}
		}
		return answer;
	}
}