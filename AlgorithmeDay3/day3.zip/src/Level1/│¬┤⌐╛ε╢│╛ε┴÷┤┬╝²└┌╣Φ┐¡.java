package Level1;

import java.util.ArrayList;
import java.util.Arrays;

public class 나누어떨어지는숫자배열 {

	public static void main(String[] args) {
		int[] arr = { 3,2,6 }; // [5,10] (오름차순 정렬)
		int div = 10;

		Solution8 sol = new Solution8();
		int[] result = sol.solution(arr, div);
		System.out.println(Arrays.toString(result));
	}

}

class Solution8 {
	public int[] solution(int[] arr, int divisor) {
		int count = 0;
		ArrayList<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % divisor == 0) {
				count++;
				list.add(arr[i]);
			}
		}

		if (count == 0) {
			int[] answer = { -1 };
			return answer;
		} else {
			int[] answer = new int[count];
			
			// list를 바로 배열로 바꿔서 for문 대신에 stream()을 사용할 수도 있음
			for (int i = 0; i < list.size(); i++) {
				answer[i] = list.get(i);
			}

			Arrays.sort(answer);
			return answer;
		}

	}
}