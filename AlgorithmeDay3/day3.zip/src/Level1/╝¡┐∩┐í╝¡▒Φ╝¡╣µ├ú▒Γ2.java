package Level1;

public class 서울에서김서방찾기2 {

	public static void main(String[] args) {
		String[] seoul = {"Jane", "Kim"};
		
		Solution10 sol = new Solution10();
		String result = sol.solution(seoul);
		System.out.println(result);
	}

}

class Solution10 {
    public String solution(String[] seoul) {
        String answer = "";
        int location = 0;
        
        for (int i = 0; i < seoul.length; i++) {
			if (seoul[i].equals("Kim")) {
				location = i;
			}
		}
        answer = "김서방은 " + location + "에 있다";
        
        return answer;
    }
}