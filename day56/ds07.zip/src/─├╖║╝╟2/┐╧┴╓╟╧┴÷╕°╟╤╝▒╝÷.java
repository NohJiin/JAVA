package 컬렉션2;

import java.util.HashMap;

public class 완주하지못한선수 {

	public static void main(String[] args) {
		String[] all = {"leo", "kiki", "eden", "eden"};	// -> eden, kiki
		// 동명이인이 존재한다
		String[] end = {"kiki", "eden"};
		
		HashMap<String, Integer> map = new HashMap<>();
		
		String no = "";
		for (String key : all){
			map.put(key, map.getOrDefault(key, 0) + 1);
			}
		
		for (String key : end){
			map.put(key, map.getOrDefault(key, 0) - 1);
		}
		
		for (String key : map.keySet()){
			if (map.get(key) != 0) {
				no += key + " ";
			}
		}
		System.out.println(map);
		System.out.println("완주하지 못한 사람 : " + no);
		
	}

}