package 컬렉션2;

import java.util.Scanner;
import java.util.TreeSet;

public class K번째큰수_비선형구조_tree {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("k번째 : ");
		int k = sc.nextInt();

		TreeSet<Integer> tree = new TreeSet<Integer>();

		while (true) {
			int data = sc.nextInt();
			if (data == 0) {
				break;
			} else {
				tree.add(data);
			}
		}

		System.out.println(tree);

		Object[] res = tree.toArray();
		System.out.println(k + "번 째 작은 수 : " + res[k - 1]);
	}

}