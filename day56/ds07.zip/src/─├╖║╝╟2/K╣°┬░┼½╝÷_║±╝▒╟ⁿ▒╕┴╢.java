package 컬렉션2;

import java.util.Arrays;
import java.util.Scanner;

public class K번째큰수_비선형구조 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("입력 개수 : ");
		int size = sc.nextInt();

		int[] num = new int[size];
		System.out.println("k번째 작은 수 : ");
		int k = sc.nextInt(); // 2번째 작은 수

		for (int i = 0; i < num.length; i++) {
			num[i] = sc.nextInt();
		}
		Arrays.sort(num);
		System.out.println(Arrays.toString(num));

		System.out.println(k + "번 째 작은 수 : " + num[k - 1]);
	}

}