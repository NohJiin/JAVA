package 컬렉션2;

import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeSet;

public class K번째큰수_선형구조 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("입력 개수 : ");
		int size = sc.nextInt(); // 12번 입력

		int[] num = new int[size];
		System.out.println("k번째 작은 수 : ");
		int k = sc.nextInt(); // 3번째 작은 수

		TreeSet<Integer> set = new TreeSet<>();
		for (int i = 0; i < num.length; i++) {
			set.add(sc.nextInt()); // 중복된 값도 입력
		}

		System.out.println(set);
		Object[] res = set.toArray();
		System.out.println(k + "번째 작은 수 : " + res[k - 1]);
	}

}