package 컬렉션2;

import java.util.HashMap;

public class HashMap확인문제 {

	public static void main(String[] args) {
		// 좋아하는 과일, 투표결과 "apple, banana, apple, banana, melon, apple"이 나옴
		// 전체 과일별 득표수를 프린트
		// 어떤 과이링 제일 많이 나왔는지 득표수와 과일명 프린트
		// 어떤 과일들이 있었는지 과일명 프린트
		String[] all = {"apple", "banana", "apple", "banana", "melon", "apple", "banana", "banana"};
		HashMap<String, Integer> f = new HashMap<>();
		
		int maxVal = 0;
		String maxKey = "";
		for (String key : all) {
			f.put(key, f.getOrDefault(key, 0) + 1);
			if (f.get(key) > maxVal) {
				maxVal = f.get(key);
				maxKey = key;
			}
		}
		System.out.println(f);
		System.out.println("가장 많이 나온 과일 : " + maxKey + ", " + maxVal + "번");
		System.out.println(f.keySet());
	}

}