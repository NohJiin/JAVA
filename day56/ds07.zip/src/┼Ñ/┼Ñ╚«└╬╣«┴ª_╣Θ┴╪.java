package 큐;

import java.util.LinkedList;

public class 큐확인문제_백준 {

	public static void main(String[] args) {
		LinkedList<Integer> q = new LinkedList<>();
		q.add(1);
		q.add(2);
		System.out.println(q.peek());
		System.out.println(q.get(q.size()-1));
		System.out.println(q.size());
		System.out.println(q.isEmpty()? 1: 0);	// true : 1 false : 0
		try {
			System.out.println(q.remove());
			System.out.println(q.remove());
			System.out.println(q.remove());
		} catch (Exception e) {
			System.out.println("-1");
		}
		System.out.println(q.size());
		System.out.println(q.isEmpty()? 1: 0);	// true : 1 false : 0
		try {
			System.out.println(q.remove());
		} catch (Exception e) {
			System.out.println("-1");
		}
		q.add(3);
		System.out.println(q.isEmpty()? 1: 0);	// true : 1 false : 0
		System.out.println(q.peek());
	}

}