package 큐;

import java.util.LinkedList;

public class 백준_카드2문제 {

	public static void main(String[] args) {
		int x=  6;
		LinkedList<Integer> q = new LinkedList<>();
		for (int i = 1; i <= x; i++) {
			q.add(i);
		}
		System.out.println(q);
		
		for (int i = 0; i <= q.size(); i++) {
			q.remove();
			System.out.println("remove> " + q);
			q.add(q.remove());
			System.out.println("add> " + q);
		}
		q.remove();
		System.out.println("queue에 남은 것 >> " + q);
	}
}