package 스택;

import java.util.Arrays;
import java.util.Stack;

public class 자연수뒤집어배열로만들기 {

	public static void main(String[] args) {
		int n = 12345;
		Stack<String> stack = new Stack<>();
		
		// 하나씩 분리시키고
		String[] s = String.valueOf(n).split("");
		System.out.println(Arrays.toString(s));
		
		// stack에 순서대로 넣기
		for (String x : s) {
			stack.push(x);
		}
		
		// int[]에 옮기기
		int[] answer = new int[stack.size()];
		for (int i = 0; i < s.length; i++) {
			answer[i] = Integer.parseInt(stack.pop());
		}
		System.out.println(Arrays.toString(answer));
		
	}

}