package com.jiin.mvc01;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

@Component	// 싱글톤 객체로 생성
public class MemberDAO {
	
	@Autowired
	SqlSessionTemplate my;
	
	// insert 함수 생성
	public int insert(MemberVO bag) {
		int result = my.insert("member.create",	bag);
		return result;
	}
	
	public int login(MemberVO bag) {
		MemberVO bag2 = my.selectOne("member.login", bag);
		
		int result = 0;
		if (bag2.getId().equals(null)) {
			return result;
		} else {
			result = 1;
			return result;
		}
	}
	
	public MemberVO one(String id, Model model) {
		MemberVO bag = my.selectOne("member.one", id);	// 검색결과를 저장
		return bag;
	}
	
	public List<MemberVO> list() {
		List<MemberVO> list = my.selectList("list");	// 모든 멤버의 리스트를 담고있음,	넘겨줄 변수가 필요하지 않음
		return list;
	}
}