package com.jiin.mvc01;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller	// 컨트롤러 생성하기
public class MemberController {
	
	@Autowired	// RAM에서 생성된 MemberDAO객체를 찾아서 가져옴 -> 싱글톤
	MemberDAO dao;
	
	@RequestMapping("login")
	public String login(MemberVO bag, HttpSession session) {
		System.out.println(bag.getId() + "으로 login 실행");
		
		// 로그인 실행
		int result = dao.login(bag);	//  값이 1이면 로그인가능, 0이면 로그인 실패
		System.out.println("로그인 결과 : " + result);		// 1이면 로그인 성공, 0이면 로그인 실패
		if (result == 1) {
			session.setAttribute("id", bag.getId());
			return "redirect:main.jsp";
		} else {
			return "redirect:login.jsp";
		}
	}
	
	@RequestMapping("join")
	public void insert(MemberVO bag) {
		System.out.println("insert 요청됨");
		System.out.println(bag);	// insert요청된 값들을 확인

		dao.insert(bag);	// insert함수 실행하기 (DB에 데이터 전달)
	}
	
	@RequestMapping("list")	// 관리자만 접근할 수 있으면 좋겠음 -> 세션사용해야한다
	public void list(Model model) {
		System.out.println("관리자 접근 => 회원 정보 접근");
		
		List<MemberVO> list = dao.list();
		model.addAttribute("list", list);		// 처리결과를 views에서 가져오기 위해서 model생성
	}
}