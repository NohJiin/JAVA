package Level1;

public class 약수의합 {

	public static void main(String[] args) {
		int n = 12;
		Solution2 sol = new Solution2();
		int result = sol.solution(n);
		System.out.println(result);
	}

}

class Solution2 {
    public int solution(int n) {
    	// 모든 정수의 약수에는 1과 자기 자신 포함되므로
    	int answer = 1 + n;
    	
    	for (int i = 2; i < n; i++) {
			if (n % i == 0) {
				answer += i;
			}
		}
    	
        return answer;
    }
}