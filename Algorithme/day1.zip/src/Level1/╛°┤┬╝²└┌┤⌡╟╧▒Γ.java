package Level1;

import java.util.ArrayList;

public class 없는숫자더하기 {

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 6, 7, 8, 0 };

		Solution sol = new Solution();
		int result = sol.solution(arr);
		System.out.println(result);

	}

}

class Solution {
	public int solution(int[] numbers) {
		int answer = 0;
		
		// 0~9까지의 정수값을 가지는 ArrayList를 만든다
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i <= 9; i++) {
			list.add(i);
		}

		// solution함수로 전달받은 numbers 배열을 ArrayList로 변환한다
		ArrayList<Integer> num = new ArrayList<Integer>();
		// numbers의 값을 저장하는 것이기 때문에 for문도 numbers.length까지
		for (int i = 0; i < numbers.length; i++) {
			num.add(numbers[i]);
		}
		
		// contains함수를 사용해서 num에 포함되지 않는 값을 answer에 더한다
		for (Integer x : list) {
			if (!num.contains(x)) {
				answer += x;
			}
		}
		
		return answer;
	}
}