package 프로그래머스;


public class 배열의평균값 {

	public static void main(String[] args) {
		int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		
		Solution7 sol = new Solution7();
		double answer = sol.solution(numbers);
		System.out.println(answer);
	}
	
}

class Solution7 {
	public double solution(int[] numbers) {
		int sum = 0;
		for (int i : numbers) {
			sum = sum + i;
		}
        double answer = (double)sum/numbers.length;	// (double)는 cpu가 처리한 것
        return answer;
    }
}