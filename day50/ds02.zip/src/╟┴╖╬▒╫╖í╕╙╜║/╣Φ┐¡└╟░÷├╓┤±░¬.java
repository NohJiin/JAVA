package 프로그래머스;

import java.util.Arrays;

public class 배열의곱최댓값 {

	public static void main(String[] args) {
		// [1, 2, 3, 4, 5] : 20
		// [0, 31, 24, 10, 1, 9] : 744
		// 두 수를 곱했을 때 가장 큰 숫자를 구해보라
		// 배열이 오름차순으로 정렬ㄹ이 되어있는 상태
		int[] numbers = {0, 31, 24, 10, 1, 9};

		Solution10 sol = new Solution10();
		double answer = sol.solution(numbers);
		System.out.println(answer);
	}

}

class Solution10 {
	public int solution(int[] numbers) {
		Arrays.sort(numbers);	// 파괴형
        int answer = numbers[numbers.length - 1] * numbers[numbers.length - 2];
        return answer;
    }
}