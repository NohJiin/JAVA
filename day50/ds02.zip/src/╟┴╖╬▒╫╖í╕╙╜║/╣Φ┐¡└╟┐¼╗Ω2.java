package 프로그래머스;

public class 배열의연산2 {

	public static void main(String[] args) {
		// 세 수를 더했을 때 가장 큰 숫자를 구해보라
		// 배열이 오름차순으로 정렬ㄹ이 되어있는 상태
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		Solution8 sol = new Solution8();
		double answer = sol.solution(numbers);
		System.out.println(answer);
	}

}

class Solution8 {
	public int solution(int[] numbers) {
		int sum = 0;
		int size = numbers.length - 1;
		for (int i = size; i > (size - 3); i--) {
			sum = sum + numbers[i];
			System.out.println(numbers[i]);
		}
		int answer = sum;
		return answer;
	}
}