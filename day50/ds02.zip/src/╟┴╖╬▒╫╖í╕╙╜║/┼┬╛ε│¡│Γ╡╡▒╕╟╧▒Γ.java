package 프로그래머스;

import java.util.Scanner;

public class 태어난년도구하기 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		
		Solution5 sol = new Solution5();
		int answer = sol.solution(age);
		System.out.println(answer);
		sc.close();
	}
	
}

class Solution5 {
	public int solution(int age) {
        int answer = 2022 - age + 1;
        return answer;
    }
}