package 프로그래머스;

import java.util.Arrays;

public class 배열의곱최댓값2 {

	public static void main(String[] args) {
		// [1, 2, 3, 4, 5] : 20
		// [0, 31, 24, 10, 1, 9] : 744
		// 두 수를 곱했을 때 가장 큰 숫자를 구해보라
		// 배열이 오름차순으로 정렬ㄹ이 되어있는 상태
		int[] numbers = {1, 2, -3, 4, -5};

		Solution11 sol = new Solution11();
		int answer = sol.solution(numbers);
		System.out.println(answer);
	}

}

class Solution11 {
	public int solution(int[] numbers) {
		Arrays.sort(numbers);	// 파괴형
		int post = numbers[numbers.length - 1] * numbers[numbers.length - 2];
		int pre = numbers[0] * numbers[1];
		
		int answer = 0;
		if (post > pre) {
			answer = post;
		} else {
			answer = pre;
		}
        return answer;
    }
}