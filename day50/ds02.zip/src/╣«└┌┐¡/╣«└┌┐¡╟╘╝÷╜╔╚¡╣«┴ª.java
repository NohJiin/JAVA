package 문자열;

import java.util.Arrays;

public class 문자열함수심화문제 {

	public static void main(String[] args) {
		String s5 = "[ 10, 20, 30, 40, 50]";
		
		// [, ] – replace()를 이용하여 제거
		s5 = s5.replace("[", "");
		s5 = s5.replace("]", "");		// 비파괴함수
		System.out.println(s5);
		
		// 10 - trim()을 이용하여 공백 제거
		s5 = s5.trim();		// 비파괴함수
		System.out.println(s5);
		
		// ,를 기준으로 split()를 이용하여 배열로 분리
		System.out.println(s5.length());	// 18글자
		String[] s55 = s5.split(", ");	// 쉼표 + 공백까지 로 split, 비파괴함수
		System.out.println(s55[0]);
		System.out.println(s55[1]);
		System.out.println(s55[2]);
		
		// 배열로 분리된 값을 꺼내 정수로 변환후, 합해줌.
		int sum = 0;
		for (String x : s55) {
			sum = sum + Integer.parseInt(x);
		}
		System.out.println("전체 합 : " + sum);
		
		// 7. 위 6번에서 생성된 String[]의 값을 새로운  int[]로 옮겨서 프린트!
		int[] newArray = new int[s55.length];	// {0,0,0,0,0}
		for (int i = 0; i < newArray.length; i++) {
			newArray[i] = Integer.parseInt(s55[i]);
		}
		
		System.out.println(newArray.toString());	// 주소값이 찍힌다.
		System.out.println(Arrays.toString(newArray));	// 배열의 값을 String으로 만들어준다.
	}

}