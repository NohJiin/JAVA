package 문자열;

import java.util.Arrays;

public class 스트링을배열로 {
	public static void main(String[] args) {
		String all = "국어, 영어, 수학, 컴퓨터";
		// 1. String[]로 바구어보세요
		String[] all2 = all.split(", ");
		
		for (int i = 0; i < all2.length; i++) {
			if (all2[i].contains(" ")) {
				all2[i] = all2[i].trim();
			}
		}
		
		System.out.println(Arrays.toString(all2));
		System.out.println("과목 수 : " + all2.length);
		
		int set = 0;
		int count = 0;
		for (int i = 0; i < all2.length; i++) {
			if(all2[i].equals("컴퓨터")) {
				set = i;
			}
			if (all2[i].length() < 3) {
				count++;
			}
		}
		System.out.println("컴퓨터의 위치 : " + set);
		System.out.println("과목명이 3글자 미만인 과목수 : " + count);
		
		
		// 2. 바꾸었더니 공백이 포함되어있다면, 공백을 모두 제거 후 다시 배령에 넣어라
		// 3. 과목수?
		// 4. 컴퓨터의 위치?
		// 5. 과목명이 3글자 미만인 과목수는?
	}
}
