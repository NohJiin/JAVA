package Level1;

import java.util.ArrayList;
import java.util.Arrays;

public class 최대공약수와최소공배수2 {
	public static void main(String[] args) {
		int n = 12;	// 1, 3
		int m = 14;	// 1, 2, 3, 4, 6, 12
		
		Solution15 sol = new Solution15();
		int[] result = sol.solution(n, m);
		System.out.println(Arrays.toString(result));
	}

}

class Solution15 {
    public int[] solution(int n, int m) {
    	int max = Math.max(n,  m);
    	int min = Math.min(n, m);
    	
    	while (min != 0) {
			int r = max % min;
			max = min;
			min = r;
		}
    	
    	int gcd = n * m / max;
    	
        int[] answer = {max, gcd};
        return answer;
    }
}

// 맨 처음 풀이
//	int min = 0;	// 최소 공배수
//	int max = 0;	// 최대 공약수
//	if (n == m) {
//		max = n;
//		min = n;
//	} else if (n > m) {
//		if (m == 1) {
//			min = n;
//			max = m;
//		} else if (n % m == 0) {
//			max = m;
//			min = n;
//		} else {
//			min = m * n;
//			max = 1;
//	//		ArrayList<Integer> list = new ArrayList<Integer>();
//	//		for (int i = 1; i <= (m / 2); i++) {
//	//			if (m % i == 0) {
//	//				list.add(i);
//	//			}
//	//		}
//	//		
//	//		for (int i = list.size(); i > 0; i--) {
//	//			if (n % list.get(i) == 0) {
//	//				max = list.get(i);
//	//				break;
//	//			}
//	//		}
//		}
//	} else {
//		if (n == 1) {
//			min = n;
//			max = m;
//		} else if (m % n == 0) {
//			max = n;
//			min = m;
//		} else {
//			min = m * n;
//			max = 1;
//	//		ArrayList<Integer> list = new ArrayList<Integer>();
//	//		for (int i = 1; i <= (n / 2); i++) {
//	//			if (n % i == 0) {
//	//				list.add(i);
//	//			}
//	//		}
//	//		for (int i = list.size(); i > 0; i--) {
//	//			if (m % list.get(i) == 0) {
//	//				max = list.get(i);
//	//				break;
//	//			}
//	//		}
//		}
//	}
//	
//	int[] answer = new int[2];
//	answer[0] = max;
//	answer[1] = min;
//	return answer;