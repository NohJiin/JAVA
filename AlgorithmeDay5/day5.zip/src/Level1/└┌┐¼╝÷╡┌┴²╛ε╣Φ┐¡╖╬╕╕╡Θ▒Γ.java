package Level1;

import java.util.Arrays;

public class 자연수뒤집어배열로만들기 {

	public static void main(String[] args) {
		long n = 12345;
		Solution3 sol = new Solution3();
		int[] result = sol.solution(n);
		System.out.println(Arrays.toString(result));
	}

}

class Solution3 {
	public int[] solution(long n) {
		// 받은 정수값을 String으로 저장
		String temp = Long.toString(n);
		System.out.println(temp + ", 길이: " +  temp.length());
		
		// answer 배열의 크기를 temp의 길이와 동일하게
		int[] answer = new int[temp.length()];

		// answer에 n값을 넣는다
		for (int i = 0, j = answer.length -1; i < answer.length; i++, j--) {
			answer[i] = temp.charAt(j) -'0';
			// System.out.println(answer[i] + ", temp[" + j + "]: " + temp.charAt(j));
		}
		return answer;
	}
}

/*	public int[] solution(long n) {
    int[] answer;
    int count=0;
    long temp= n;
    while(temp !=0){
        count++;
        temp/=10;
    }
    answer = new int[count];
    for(int i = 0;i<count;i++){
        answer[i] =(int)(n%10);
          n/=10;
    }

    return answer;
}	*/