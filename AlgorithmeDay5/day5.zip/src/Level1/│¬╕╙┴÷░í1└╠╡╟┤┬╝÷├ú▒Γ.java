package Level1;

public class 나머지가1이되는수찾기 {

	public static void main(String[] args) {
		// n을 x값으로 나눌 때(3 <= n <= 1000000)
		// 나머지가 1이 되게하는 가장 작은 x를 찾아라
		int n = 10; // -> 1 / 12 -> 11
		Solution4 sol = new Solution4();
		int result = sol.solution(n);
		System.out.println(result);
	}

}

class Solution4 {
	public int solution(int n) {
		int answer = n; // 제일 작은 값 저장
		for (int i = 2; i < n; i++) {
			if (n % i == 1 && answer >= i) {
				answer = i;
			}
		}
		return answer;
	}
}