package Level1;

import java.util.Arrays;

public class K번째수 {

	public static void main(String[] args) {
		int[] array = { 1, 5, 2, 6, 3, 7, 4 };
		int[][] com = { { 2, 5, 3 }, { 4, 4, 1 }, { 1, 7, 3 } };
		System.out.println(com.length);	// 행의 길이를 출력
		
		 Solution11 sol = new Solution11(); int[] result = sol.solution(array, com);
		 System.out.println(Arrays.toString(result));
		 
	}

}

class Solution11 {
	public int[] solution(int[] array, int[][] commands) {
		// commands.length = 행의 개수(?)이므로 총 결과값을 넣을 배열의 크기로 지정할 수 있음
		int[] answer = new int[commands.length];
		
		for (int i = 0; i < commands.length; i++) {
			// commands의 첫 행부터 차례로 배열의 길이를 지정
			// 첫 행에서 요구되는 배열의 길이 = 5(commands[0][1]) - 2(commands[0][0]) + 1 이므로 아래가 성립
			int[] arr = new int[commands[i][1] - commands[i][0] + 1];
			// array에서 저장할 첫 번째 index값 = commands[0][0]에서 1을 뺀 값으로 지정
			int start = commands[i][0] - 1;
			for (int j = 0; j < arr.length; j++) {
				// arr의 크기만큼 수를 채우기,
				// start index값에서 j값이 증가하는 만큼 array의 index값을 키워줌
				arr[j] = array[start + j];
			}
			Arrays.sort(arr);
			answer[i] = arr[commands[i][2] - 1];
		}
		return answer;
	}
}