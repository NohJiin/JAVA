package Level1;

import java.util.HashMap;

public class 서울에서김서방찾기 {

	public static void main(String[] args) {
		String[] seoul = {"Jane", "Kim"};
		
		Solution9 sol = new Solution9();
		String result = sol.solution(seoul);
		System.out.println(result);
	}

}

class Solution9 {
    public String solution(String[] seoul) {
        String answer = "";
        
        HashMap<String, Integer> map = new HashMap();
        for (int i = 0; i < seoul.length; i++) {
        	map.put(seoul[i], i);
        	System.out.println(map.get(seoul[i]));
		}
        int location = map.get("Kim");
        answer = "김서방은 " + location + "에 있다";
        
        return answer;
    }
}