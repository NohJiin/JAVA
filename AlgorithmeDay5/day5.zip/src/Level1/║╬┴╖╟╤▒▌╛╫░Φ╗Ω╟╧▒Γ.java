package Level1;

public class 부족한금액계산하기 {

	public static void main(String[] args) {
		int price = 3;
		int money = 20;
		int count = 4;

		Solution7 sol = new Solution7();
		long result = sol.solution(price, money, count);
		System.out.println(result + "원 부족");
	}

}

class Solution7 {
    public long solution(int price, int money, int count) {
    	long answer = 0;
    	long total = 0;
    	
    	for (int i = 1; i <= count; i++) {
    		total += i * price;
    	}

    	answer = money - total;
    	
    	if (answer < 0) {
    		return answer * (-1);
		} else {
			return 0;
		}
    }
}

/*		long answer = 0;
    	
    	for (int i = 1; i <= count; i++) {
			money -= i * price;
		}
    	
    	if (money < 0) {
			answer = money*(-1);
		}

        return answer;
*/