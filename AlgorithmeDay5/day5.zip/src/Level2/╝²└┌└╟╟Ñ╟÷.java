package Level2;

public class 숫자의표현 {

	public static void main(String[] args) {
		int n = 15;
		
		Solution3 sol = new Solution3();
		int res = sol.solution(n);
        
		System.out.println("개수 : " + res);
	}

}

class Solution3 {
    public int solution(int n) {
        int answer = 0;
        
        for (int i = 1; i <= n; i++) {
        	String arr = "";
        	int sum = 0;
        	for (int j = i; j <= n; j++) {
				sum += j;
				arr += j + " + ";
				if (sum > n) {
					break;
				} else if (sum == n) {
					answer++;
					arr += "= " + n;
					System.out.println(arr);
					break;
				}
			}
        }

        return answer;
    }
}

//class Solution {
//    public int solution(int n) {
//        int answer = 0;
//        
//        for (int i = 1; i <= n; i++) {
//        	int sum = 0;
//        	for (int j = i; j <= n; j++) {
//				sum += j;
//				if (sum > n) {
//					break;
//				} else if (sum == n) {
//					answer++;
//					break;
//				}
//			}
//        }
//
//        return answer;
//    }
//}