package Level2;

import java.util.Arrays;

public class 최댓값과최솟값 {
	public static void main(String[] args) {
		String s = "1 2 3 4";
		
		Solution sol = new Solution();
		String result = sol.solution(s);
		System.out.println(result);
	}
}

class Solution {
    public String solution(String s) {
    	String[] arr = s.split(" ");
    	int[] result = new int[arr.length];
    	
    	for (int i = 0; i < result.length; i++) {
			result[i] = Integer.parseInt(arr[i]);
		}
    	
    	Arrays.sort(result);
    	System.out.println(Arrays.toString(result));
    	
        String answer = "";
        
        answer = result[0] + " " + result[result.length - 1];
        return answer;
    }
}