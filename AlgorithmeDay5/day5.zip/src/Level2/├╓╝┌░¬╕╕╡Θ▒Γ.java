package Level2;

import java.util.Arrays;

public class 최솟값만들기 {

	public static void main(String[] args) {
		int[] A = {1, 2};
		int[] B = {3, 4};
		
		Solution2 sol = new Solution2();
		int res = sol.solution(A, B);
        
		System.out.println("최솟값 : " + res);
	}

}

class Solution2{
    public int solution(int []A, int []B)
    {
        int answer = 0;
        Arrays.sort(A);
        Arrays.sort(B);
        
        for (int i = 0, j = (A.length - 1); i < A.length; i++, j--) {
			answer += A[i] * B[j];
		}
        
        return answer;
    }
}