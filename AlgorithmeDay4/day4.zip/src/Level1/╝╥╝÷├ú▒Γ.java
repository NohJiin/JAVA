package Level1;

public class 소수찾기 {

	public static void main(String[] args) {
		// 2 <= n <= 1,000,000
		int n = 10;	// 4개	5 -> 3개
		Solution12 sol = new Solution12();
		int result = sol.solution(n);
		System.out.println(result + "개");
		
	}

}

class Solution12 {
    public int solution(int n) {
        int answer = 1;	// 2가 포함된 수
        int count = 1;	// 자기 자신을 나눴을 때 나머지가 0인 경우
        
        if (n == 2) {
			return 1;
		} else {
			// 짝수인 경우는 제외하기 위해서 i를 1씩이 아닌 2씩 증가시킴
			for (int i = 3; i <= n; i+=2) {
				// 짝수를 이미 제외 시켜서 짝수로 나눠지는 경우는 생각할 필요가 없으므로
				// j를 2씩 증가함
				for (int j = 3; j < i; j+=2) {
					if (i % j == 0) {
						count++;
						break;
					}
				}
				if (count == 1) {
					answer++;
				}
				count = 1;
			}
			return answer;
		}
    }
}