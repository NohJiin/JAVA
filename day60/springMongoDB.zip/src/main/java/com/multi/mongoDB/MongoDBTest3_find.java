package com.multi.mongoDB;

import java.util.ArrayList;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDBTest3_find {

	public static void main(String[] args) {
		// 1. MongoDB 프로그램에 연결
		MongoClient client = new MongoClient("localhost", 27017);
		System.out.println("1. MongoDB 프로그램 연결 성공");
		// 2. shop2로 연결
		MongoDatabase database = client.getDatabase("shop2");
		System.out.println("2. shop2 DB로 연결 성공");
		// 3. member collection(= table)에 연결
		MongoCollection<Document> collection = database.getCollection("memo");
		System.out.println("3. memo 컬렉션에 연결 성공");
		
		FindIterable<Document> list = collection.find();
		ArrayList<MemoVO> result = new ArrayList<MemoVO>();
		for (Document doc : list) {
			MemoVO bag = new MemoVO();
			bag.setName(doc.getString("name"));
			bag.setAge(doc.getInteger("age"));
			bag.setOffice(doc.getString("office"));
			bag.setPhone(doc.getString("phone"));
			result.add(bag);
		}
		System.out.println(result);
	}

}