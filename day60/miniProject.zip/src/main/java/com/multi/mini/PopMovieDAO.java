package com.multi.mini;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PopMovieDAO {
	@Autowired
	SqlSessionTemplate my;
	
	public PopMovieVO one(int id) {
		PopMovieVO bag = my.selectOne("popmovie.one", id);
		return bag;
	}
	
	public List<PopMovieVO> list() {
		List<PopMovieVO> list = my.selectList("popmovie.all");
		return list;
	}
}