package com.multi.mini;

public class ActorVO {
	private int actorId;
	private String actorNm;
	private String nationality;
	private String actorImg;
	
	public int getActorId() {
		return actorId;
	}
	public void setActorId(int actorId) {
		this.actorId = actorId;
	}
	public String getActorNm() {
		return actorNm;
	}
	public void setActorNm(String actorNm) {
		this.actorNm = actorNm;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getActorImg() {
		return actorImg;
	}
	public void setActorImg(String actorImg) {
		this.actorImg = actorImg;
	}
	
	@Override
	public String toString() {
		return "ActorVO [actorId=" + actorId + ", actorNm=" + actorNm + ", nationality=" + nationality + ", actorImg="
				+ actorImg + "]";
	}
}