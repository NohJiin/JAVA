package com.multi.mini;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PopMovieController {
	@Autowired
	PopMovieDAO dao;
	
	@RequestMapping("popmovieOne")
	public void one(int id, Model model) {
		System.out.println("검색기능 요청 >> id:" + id);
		PopMovieVO bag = dao.one(id);
		
		model.addAttribute("bag", bag);
	}
	
	@RequestMapping("list")
	public void list(Model model) {
		System.out.println("전체 목록 요청");
		List<PopMovieVO> list = dao.list();
		
		model.addAttribute("list", list);
	}
}