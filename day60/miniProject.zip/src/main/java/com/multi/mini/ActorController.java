package com.multi.mini;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ActorController {
	@Autowired
	ActorDAO dao;
	
	@RequestMapping("one2")
	public void one(int actorId, Model model) {
		System.out.println("검색기능 요청 >> id:" + actorId);
		ActorVO bag = dao.one(actorId);
		
		model.addAttribute("bag", bag);
	}
	
	@RequestMapping("actorList")
	public void list(Model model) {
		System.out.println("전체 목록 요청");
		List<ActorVO> list = dao.list();
		
		model.addAttribute("list", list);
	}
}