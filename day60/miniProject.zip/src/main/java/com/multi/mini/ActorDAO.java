package com.multi.mini;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ActorDAO {
	@Autowired
	SqlSessionTemplate my;
	
	public ActorVO one(int actorId) {
		ActorVO bag = my.selectOne("actor.one", actorId);
		return bag;
	}
	
	public List<ActorVO> list() {
		List<ActorVO> list = my.selectList("actor.all");
		return list;
	}
}