package 컬렉션;

public class 배열과컬렉션변환2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
