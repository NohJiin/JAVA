package 배열;

import java.util.*; // Date, random, Collections, Arrays
// import java.lang.*; ==> System, Integer, String

public class 배열두배로 {

	public static void main(String[] args) {
		int[] numbers = { 1, 2, 3, 4, 5 };
		Solution1 sol = new Solution1();
		int[] answer = sol.solution(numbers);
		System.out.println(Arrays.toString(answer)); // array에 있는 배열을 모두 가져옴
	}
}

class Solution1 {
	public int[] solution(int[] numbers) {
		// 답안을 작성해서 집어넣을 배열을 만들었음
		int[] answer = new int[numbers.length]; // {1,2,3} => {2,4,6}

		// 1. 반목문을 이용해서
		// 2. numbers 배열 인덱스를 0부터 하나씩 꺼내와서
		// 3. 2배로 곱한 후,
		// 4. answer배열 같은 위피에 넣는다.
		for (int i = 0; i < answer.length; i++) {
			answer[i] = numbers[i] * 2;
		}

		return answer;
	}
}