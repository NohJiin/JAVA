package 배열;

public class 프로그래머스0 {

	public static void main(String[] args) {
		int angle = 100;
		Solution0 sol = new Solution0();
		int answer = sol.solution(angle);
		System.out.println(answer);
	}
}

class Solution0 {
	public int solution(int angle) {
		int answer = 0;

		return answer;
	}
}