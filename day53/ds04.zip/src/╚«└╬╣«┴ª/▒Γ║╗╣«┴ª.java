package 확인문제;

public class 기본문제 {

	public static void main(String[] args) {
		String message = "happy birthday!";	// 15 -> 30
		String message2 = "i love you~";	// 11 -> 22
		
		Solution sol = new Solution();
		int res = sol.solution(message);
		int res2 = sol.solution(message2);
		
		System.out.println("happy birthday! : " + res + "글자" );
		System.out.println("happy birthday! : " + res2 + "글자" );
	}

}

class Solution {
	public int solution(String message) {
		int answer = 0;
		
		answer = message.length() * 2;
		
		return answer;
	}
}