package Level1;

public class 없는숫자더하기2 {

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 6, 7, 8, 0 };

		Solution2_2 sol = new Solution2_2();
		int res = sol.solution(arr);
		System.out.println("결과 값 : " + res);

	}

}

class Solution2_2 {
	public int solution(int[] numbers) {
		int answer = 0;
		
		// 0~9까지의 합
		for (int i = 1; i < 10; i++) {
			answer += i;
		}
		System.out.println("all : " + answer);
		
		// 모든 원소의 값이 다르기 때문에 for문 사용가능
		for (int i = 0; i < numbers.length; i++) {
			System.out.println(numbers[i]);
			answer = answer - numbers[i];
		}
		
		return answer;
	}
}